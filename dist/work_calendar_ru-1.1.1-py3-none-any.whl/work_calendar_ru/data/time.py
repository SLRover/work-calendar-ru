# -*- coding: utf-8 -*-

import datetime

work_hours = (datetime.time(8, 0, 0), datetime.time(20, 0, 0))
