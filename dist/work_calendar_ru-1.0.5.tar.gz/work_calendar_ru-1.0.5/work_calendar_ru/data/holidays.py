# -*- coding: utf-8 -*-

import datetime

holidays = [
    datetime.date(2019, 1, 1), datetime.date(2019, 1, 2), datetime.date(2019, 1, 3), datetime.date(2019, 1, 4),
    datetime.date(2019, 1, 5), datetime.date(2019, 1, 6), datetime.date(2019, 1, 7), datetime.date(2019, 1, 8),
    datetime.date(2019, 3, 8), datetime.date(2019, 5, 1), datetime.date(2019, 5, 2), datetime.date(2019, 5, 3),
    datetime.date(2019, 5, 9), datetime.date(2019, 6, 12), datetime.date(2019, 11, 4)
]

short_days = [
    datetime.date(2019, 2, 22), datetime.date(2019, 3, 7), datetime.date(2019, 4, 30), datetime.date(2019, 5, 8),
    datetime.date(2019, 6, 11), datetime.date(2019, 12, 31)
]

work_weekends = []
