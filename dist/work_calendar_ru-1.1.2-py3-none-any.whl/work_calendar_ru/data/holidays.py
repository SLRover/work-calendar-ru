# -*- coding: utf-8 -*-

import datetime

holidays = [
    datetime.date(2020, 1, 1), datetime.date(2020, 1, 2), datetime.date(2020, 1, 3), datetime.date(2020, 1, 4),
    datetime.date(2020, 1, 5), datetime.date(2020, 1, 6), datetime.date(2020, 1, 7), datetime.date(2020, 1, 8),
    datetime.date(2020, 2, 24), datetime.date(2020, 3, 9), datetime.date(2020, 5, 1), datetime.date(2020, 5, 4),
    datetime.date(2020, 5, 5), datetime.date(2020, 5, 11), datetime.date(2020, 6, 12), datetime.date(2020, 11, 4)
]

short_days = [
    datetime.date(2020, 4, 30), datetime.date(2020, 5, 8), datetime.date(2020, 6, 11), datetime.date(2020, 11, 3),
    datetime.date(2020, 12, 31)
]

work_weekends = []
